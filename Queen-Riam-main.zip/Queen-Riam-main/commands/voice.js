const fs = require('fs')
const path = require('path')

module.exports = {
  name: 'sewvoice',

  async execute(sock, msg) {
    try {
      if (!msg.message || msg.key.fromMe) return

      const jid = msg.key.remoteJid
      const text =
        msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        ''

      if (!text) return

      const voiceDir = path.join(process.cwd(), 'VoiceClip')
      if (!fs.existsSync(voiceDir)) return

      // normalize text → filename
      const key = text.trim().toLowerCase()

      const files = fs.readdirSync(voiceDir)

      // find matching voice
      const match = files.find(f =>
        f.toLowerCase().startsWith(key)
      )

      if (!match) return

      const voicePath = path.join(voiceDir, match)

      await sock.sendMessage(jid, {
        audio: fs.readFileSync(voicePath),
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true
      })
    } catch (e) {
      console.error('Sew voice plugin error:', e)
    }
  }
}

const settings = {
  packname: 'Queen Riam',
  author: 'Hecor Manuel',
  botName: "Queen Riam",
  botOwner: 'Hector Manuel', 
  timezone: 'Africa/Accra',
  prefix: '.',
  ownerNumber: '+233509977126', 
  AUTO_STATUS_REACT: 'true',
  AUTO_STATUS_REPLY: 'false',
  AUTO_STATUS_MSG: 'Status Viewed Queen Riam',

  AUTORECORD: 'false',
  AUTOTYPE: 'false',
  AUTORECORDTYPE: 'false',
  

  

  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.0",
};

module.exports = settings;
